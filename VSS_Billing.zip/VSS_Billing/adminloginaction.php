<?php
include 'connection.php';

$username = $_REQUEST['username'];
$password = $_REQUEST['password'];


$s = "select * from admintable WHERE username='$username' and status='1'";

$result = mysqli_query($con, $s);
if (mysqli_num_rows($result) <= 0) {
    echo 1;
} else {
    $row = mysqli_fetch_array($result);
    if ($row['password'] == $password) {
        session_start();
        $_SESSION['ADMIN']=$username;
        $_SESSION['ADMINNAME']=$row[2];
        echo 3;
    }
    else
    {
        echo 2;
    }
}