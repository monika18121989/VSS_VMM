-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 20, 2021 at 06:56 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vss_bill`
--

-- --------------------------------------------------------

--
-- Table structure for table `admintable`
--

CREATE TABLE `admintable` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `admintype` varchar(50) NOT NULL,
  `dateoflogin` date NOT NULL,
  `timeoflogin` time NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admintable`
--

INSERT INTO `admintable` (`username`, `password`, `fullname`, `admintype`, `dateoflogin`, `timeoflogin`, `status`) VALUES
('admin', '12345', 'Admin', 'Administrator', '2021-12-11', '11:22:47', 1),
('monika', '12345', 'Monika', 'Administrator', '2021-12-11', '13:33:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `customertable`
--

CREATE TABLE `customertable` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customertable`
--

INSERT INTO `customertable` (`id`, `name`, `address`, `city`, `state`, `country`) VALUES
(1, 'Raman', 'Rani ka Bagh', 'Amritsar', 'Punjab', 'India'),
(2, 'Neha', 'Bus Stand', 'Amritsar', 'Punjab', 'India'),
(3, 'Dora Guthrie', 'Aut ex unde adipisic', 'Aperiam commodi amet', 'Esse deserunt irure', 'Est omnis non aut do'),
(4, 'Bryar Hewitt', 'Do molestias modi qu', 'Quos ipsam voluptas ', 'Recusandae Laborum', 'Autem non non dolore'),
(5, 'Madaline England', 'Ipsum aliqua Minim ', 'Tempor et quia rerum', 'Quae officiis commod', 'Nihil quod distincti'),
(6, 'Raymond Landry', 'Consequatur Praesen', 'Aspernatur dignissim', 'Aliquip ex sunt nisi', 'Dolor sed saepe adip'),
(7, 'Germane Allison', 'Officia est quo sit', 'Quas sunt consequunt', 'Necessitatibus moles', 'Aut libero proident'),
(8, 'Teegan Long', 'Numquam fugiat et i', 'Debitis aliquip irur', 'Temporibus aut excep', 'Aute explicabo Offi'),
(9, 'Farrah Daniel', 'Cillum blanditiis la', 'Atque minim aute mol', 'Sunt non ea dolor ei', 'Magnam enim officia '),
(10, 'Monika', 'amritsar', 'amritsar', 'punjab', 'india'),
(11, 'Palmer Skinner', 'Recusandae Dolor ut', 'Maiores et numquam s', 'Omnis minus voluptat', 'Culpa ea laboriosam'),
(12, 'Hall Cantrell', 'Dolor quidem nisi il', 'Nihil maiores ad aut', 'In voluptatem rerum', 'Doloribus quaerat op'),
(24, 'Monika', 'Khalsa College', 'Amritsar', 'Punjab', 'India'),
(40, 'Aryan', 'Amritsar', 'Amritsar', 'Punjab', 'India'),
(56, 'Khanna Paper Mill', 'Fatehgarh Churian Road', 'Amritsar', 'Punjab', 'India'),
(57, 'RS Rice Mills', 'opp. Tahla Sahib\nTarn Taran Road', 'Amritsar', 'Punjab', 'India'),
(68, 'RS Rice Mills', 'opp Tahla Sahib\nTarn Taran Road', 'Amritsar', 'Punjab', 'India'),
(88, 'Quin Waters', 'Voluptatibus molesti', 'Rerum iure voluptati', 'Sit laudantium dig', 'Officiis voluptate u'),
(89, 'RS Rice Mills', 'opp. Tahls Sahib, Taran Tarn Road', 'Amritsar', 'Punjab', 'India'),
(94, 'RS Rice Mills', 'Opp Tahla Sahib Taran Tarn', 'Amritsar', 'Punjab', 'India'),
(100, 'RS Rice Mills', 'opp. Tahla Sahib Taran Tarn Road', 'Amritsar', 'Punjab', 'India'),
(103, 'RS Rice Mills', 'opp Tahla Sahib Taran Tarn Road', 'Amritsar', 'Punjab', 'India'),
(104, 'RS Rice Mills', 'opp Tahla Sahib Taran Tarn Road', 'Amritsar', 'Punjab', 'India'),
(105, 'raman', 'jalandhar', 'jalandhar', 'punjab', 'india'),
(106, 'kiran', 'asr', 'asr', 'punjab', 'india'),
(107, 'krishna', 'ludhiana', 'ludhiana', 'punjab', 'india'),
(108, 'Quintessa Phelps', 'Ipsa expedita ducim', 'Commodo exercitation', 'Incididunt neque mag', 'Maxime in vitae illo'),
(109, 'Dawn Kline', 'Consequat Cum saepe', 'Quisquam eius et vit', 'Est dolorum non ea n', 'Veniam proident qu'),
(110, 'RS Rice Mills', 'opp. Tahls Sahib, Tarn Taran Road', 'Amritsar', 'Punjab', 'India'),
(111, 'RS Rice Mills', 'opp. Tahla Sahib, Tarn Taran Road', 'Amritsar', 'Punjab', 'India'),
(112, 'RS Rice Mills', 'opp Tahla Sahib, Tarn Taran Road', 'Amritsar', 'Punjab', 'India'),
(113, 'Meenu', 'Patiala', 'Patiala', 'Punjab', 'India'),
(114, 'Rohit', 'Batala', 'Batala', 'Punjab', 'India');

-- --------------------------------------------------------

--
-- Table structure for table `customertable_vmm`
--

CREATE TABLE `customertable_vmm` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customertable_vmm`
--

INSERT INTO `customertable_vmm` (`id`, `name`, `address`, `city`, `state`, `country`) VALUES
(1, 'Rohit', 'Batala', 'Batala', 'Punjab', 'India'),
(2, 'hjvg', 'jbhvgc', 'kjbh', 'knjb', 'nkj'),
(3, 'Chand Engineering', 'Majitha', 'Amritsar', 'Punjab', 'India');

-- --------------------------------------------------------

--
-- Table structure for table `orderdetail`
--

CREATE TABLE `orderdetail` (
  `id` int(11) NOT NULL,
  `descp1` text NOT NULL,
  `qty` float NOT NULL,
  `rate` float NOT NULL,
  `total` float NOT NULL,
  `orderno` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orderdetail`
--

INSERT INTO `orderdetail` (`id`, `descp1`, `qty`, `rate`, `total`, `orderno`) VALUES
(1, 'Voluptatem est ut a', 1, 1, 1, 3),
(2, 'support services', 2, 2, 4, 3),
(3, 'Qui aut veniam veli', 818, 19, 4, 4),
(4, 'Voluptatem perspicia', 389, 21, 5, 6),
(5, 'Eius duis officia ve', 260, 42, 41, 7),
(6, 'Eos in do eum ipsa ', 88, 78, 95, 8),
(7, 'dshvjh iusgv jshdvi', 1, 1, 1, 9),
(8, 'kjashbvg sdvhjwdb', 2, 2, 4, 9),
(9, 'Cumque maxime sit e', 523, 32, 32, 10),
(10, 'Quo quis velit vero', 316, 87, 65, 11),
(11, 'efg', 1, 1, 1, 13),
(12, 'dfbfdb', 2, 2, 4, 13),
(13, 'bfaeb', 1, 1, 1, 21),
(14, 'wefewf', 2, 1, 2, 21),
(15, 'bdsfb', 1, 1, 1, 22),
(16, 'dsvwdv', 1, 2, 2, 22),
(17, 'Support Services', 2, 300, 600, 23),
(18, 'New Features Adding', 1, 500, 500, 23),
(19, 'Support Services', 1, 200, 200, 39),
(20, 'New Features Adding', 2, 500, 1000, 39),
(21, 'Error Handling', 1, 300, 300, 39),
(22, 'New Features Adding', 2, 500, 1000, 55),
(23, 'Support Services', 2, 0, 1000, 55),
(24, 'AMC eg All Softwares & Android App', 0, 0, 70000, 56),
(25, 'gb', 1, 1, 1, 63),
(26, 'tnyn', 1, 1, 1, 64),
(27, 'sdv', 1, 1, 1, 65),
(28, 'AMC eg All Softwares & Android App', 0, 0, 70000, 67),
(29, 'rerg', 1, 1, 1, 84),
(30, 'fsbfb', 0, 0, 12, 84),
(31, 'dv sdvds efbvrwb', 0, 0, 23, 84),
(32, 'dfbe efb ef efbf ewv', 0, 0, 34, 84),
(33, 'fdvfadbv', 0, 0, 1, 86),
(34, 'fdbfgb', 0, 0, 3, 86),
(35, 'fsb fgb ', 0, 0, 2, 86),
(36, 'fvdbgbgrb', 0, 0, 6, 86),
(37, 'fbgb', 0, 0, 4, 86),
(38, 'dfbg', 0, 0, 1, 87),
(39, 'hmhrm', 0, 0, 7, 87),
(40, 'jmjhm', 0, 0, 5, 87),
(41, 'mj', 0, 0, 3, 87),
(42, 'n hm ', 0, 0, 4, 87),
(43, 'Consequatur lorem il', 656, 41, 40, 87),
(44, 'Nisi et ex corrupti', 624, 34, 98, 87),
(45, 'Quo quis voluptate a', 959, 8, 40, 87),
(46, 'Culpa delectus labo', 73, 30, 63, 87),
(47, 'sdvg', 0, 0, 1000, 88),
(48, 'sv sfvfsbv', 0, 0, 1200, 88),
(49, 'dsvdsv fsvbfsbv', 0, 0, 2500, 88),
(50, 'sdvsdv', 0, 0, 3000, 88),
(51, 'AMC eg All Softwares & Android App', 0, 0, 70000, 93),
(52, 'AMC eg All Softwares & Android App', 0, 0, 70000, 99),
(53, 'hr', 6, 6, 36, 101),
(54, 'AMC eg All Softwares & Android App', 0, 0, 70000, 102),
(55, 'AMC eg All Softwares & Android App', 0, 0, 70000, 103),
(56, 'vf nsvbhj', 0, 0, 10000, 104),
(57, 'bhjb hj jkhjk', 0, 0, 12000, 105),
(58, 'hjbhj bdj', 0, 0, 13000, 106),
(59, 'In magni voluptatem', 908, 38, 99, 107),
(60, 'Quis voluptatum numq', 295, 40, 72, 108),
(61, 'AMC eg All Softwares & Android App', 0, 0, 70000, 109),
(62, 'AMC - All Softwares & Android App', 0, 0, 70000, 110),
(63, 'AMC - All Softwares & Android App', 0, 0, 70000, 111),
(64, 'abc', 0, 0, 10000, 112),
(65, 'xyz', 0, 0, 1500, 112),
(66, 'def', 0, 0, 15000, 113),
(67, 'ghi', 0, 0, 12000, 113),
(68, 'android app', 0, 0, 45000, 114);

-- --------------------------------------------------------

--
-- Table structure for table `orderdetail_vmm`
--

CREATE TABLE `orderdetail_vmm` (
  `id` int(11) NOT NULL,
  `descp1` text NOT NULL,
  `qty` float NOT NULL,
  `rate` float NOT NULL,
  `total` float NOT NULL,
  `orderno` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orderdetail_vmm`
--

INSERT INTO `orderdetail_vmm` (`id`, `descp1`, `qty`, `rate`, `total`, `orderno`) VALUES
(1, 'PHP Project', 0, 0, 10500, 1),
(2, 'Python Project', 0, 0, 12500, 1),
(3, 'kjhg', 0, 0, 1000, 2),
(4, 'AMC of all software with 2 visits', 0, 0, 18000, 3),
(5, 'AMC of all software with 2 visits', 0, 0, 18000, 4),
(6, 'AMC of all software with 2 visits', 0, 0, 18000, 5),
(7, 'AMC of all software with 2 visits', 0, 0, 18000, 6),
(8, 'AMC of all software with 2 visits', 0, 0, 18000, 7),
(9, 'AMC of all software with 2 visits', 0, 0, 18000, 8),
(10, 'AMC of all software with 2 visits', 0, 0, 18000, 9),
(11, 'AMC of all software with 2 visits', 0, 0, 18000, 10);

-- --------------------------------------------------------

--
-- Table structure for table `ordertable`
--

CREATE TABLE `ordertable` (
  `id` int(11) NOT NULL,
  `invoiceno` int(11) NOT NULL,
  `dated` date NOT NULL DEFAULT current_timestamp(),
  `orderno` int(11) NOT NULL,
  `payment_terms` varchar(100) NOT NULL,
  `transfer_rights` varchar(20) NOT NULL,
  `total` float NOT NULL,
  `grandtotal` float NOT NULL,
  `advance` float NOT NULL,
  `balance` float NOT NULL,
  `customerid` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ordertable`
--

INSERT INTO `ordertable` (`id`, `invoiceno`, `dated`, `orderno`, `payment_terms`, `transfer_rights`, `total`, `grandtotal`, `advance`, `balance`, `customerid`, `status`) VALUES
(1, 1001, '2021-12-16', 25001, 'Cash', 'Yes', 500, 450, 300, 150, 2, 1),
(2, 1, '2021-12-16', 1001, 'Totam in exercitatio', 'Yes', 37, 35, 20, 15, 3, 1),
(3, 101, '2021-12-16', 101, 'Quaerat sed mollitia', 'Yes', 5, 5, 3, 2, 4, 1),
(4, 102, '2021-12-16', 102, 'Consequatur Distinc', 'No', 4, 4, 4, 0, 5, 1),
(5, 103, '2021-12-16', 103, 'Aspernatur et asperi', 'Yes', 100, 100, 80, 20, 6, 1),
(6, 201, '2021-12-16', 201, 'Sed possimus est s', 'Yes', 5, 5, 5, 0, 7, 1),
(7, 202, '2021-12-16', 202, 'Irure id illum cumq', 'Yes', 41, 40, 30, 10, 8, 1),
(8, 205, '2021-12-16', 205, 'Sunt voluptates aute', 'No', 95, 90, 70, 20, 9, 0),
(9, 8501, '2021-12-16', 5001, 'Cash', 'Yes', 1, 1, 1, 0, 10, 1),
(10, 9601, '2021-12-16', 5601, 'Iusto ullamco incidi', 'Yes', 32, 32, 30, 2, 11, 1),
(11, 4501, '2021-12-16', 2501, 'Reprehenderit imped', 'No', 65, 60, 40, 20, 12, 1),
(23, 6501, '2021-12-16', 3501, 'Cash', 'Yes', 1100, 1100, 800, 300, 24, 1),
(39, 2301, '2021-12-16', 4601, 'Cash', 'Yes', 1500, 1500, 900, 600, 40, 1),
(55, 7501, '2021-12-16', 9501, 'Cash', 'Yes', 2000, 2000, 1500, 500, 56, 1),
(56, 294, '2021-12-16', 4001, 'Prepaid', 'No', 70000, 70000, 0, 70000, 57, 1),
(67, 294, '2021-12-16', 2301, 'Prepaid', 'No', 0, 70000, 0, 70000, 68, 1),
(88, 296, '2021-12-16', 5201, 'Prepaid', 'No', 0, 77000, 0, 77000, 89, 1),
(93, 562, '2021-12-16', 454, 'Prepaid', 'No', 0, 70000, 0, 70000, 94, 1),
(99, 294, '2021-12-16', 1001, 'Prepaid', 'No', 0, 70000, 0, 70000, 100, 1),
(102, 294, '2021-12-16', 6601, 'Prepaid', 'Yes', 0, 70000, 0, 70000, 103, 1),
(103, 294, '2021-12-16', 1001, 'Prepaid', 'No', 0, 70000, 0, 70000, 104, 1),
(104, 5555, '2021-12-16', 4444, 'Prepaid', 'No', 0, 100000, 0, 100000, 105, 1),
(105, 7777, '2021-12-16', 6666, 'prepaid', 'Yes', 0, 12000, 0, 12000, 106, 1),
(106, 2323, '0000-00-00', 6363, 'prepaid', 'No', 0, 13000, 0, 13000, 107, 1),
(107, 78, '0000-00-00', 44, 'Repudiandae qui sunt', 'No', 0, 99, 0, 99, 108, 1),
(108, 99, '2021-12-18', 88, 'Quis consequatur Bl', 'No', 0, 72, 0, 72, 109, 1),
(109, 1001, '2021-12-17', 101, 'Prepaid', 'No', 0, 70000, 0, 70000, 110, 1),
(110, 1001, '2021-12-16', 0, 'Prepaid', 'No', 0, 70000, 0, 70000, 111, 0),
(111, 1001, '2021-12-16', 0, 'Prepaid', 'No', 0, 70000, 0, 70000, 112, 1),
(112, 7888, '2021-12-18', 9685, 'Prepaid', 'No', 0, 11500, 0, 11500, 10, 1),
(113, 87, '2021-12-16', 54, 'Prepaid', 'NA', 0, 27000, 0, 27000, 113, 1),
(114, 118, '2021-12-19', 0, 'Prepaid', 'NA', 0, 45000, 0, 45000, 114, 1);

-- --------------------------------------------------------

--
-- Table structure for table `ordertable_vmm`
--

CREATE TABLE `ordertable_vmm` (
  `id` int(11) NOT NULL,
  `invoiceno` int(11) NOT NULL,
  `dated` date NOT NULL DEFAULT current_timestamp(),
  `orderno` int(11) NOT NULL,
  `payment_terms` varchar(100) NOT NULL,
  `transfer_rights` varchar(20) NOT NULL,
  `total` float NOT NULL,
  `grandtotal` float NOT NULL,
  `advance` float NOT NULL,
  `balance` float NOT NULL,
  `customerid` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ordertable_vmm`
--

INSERT INTO `ordertable_vmm` (`id`, `invoiceno`, `dated`, `orderno`, `payment_terms`, `transfer_rights`, `total`, `grandtotal`, `advance`, `balance`, `customerid`, `status`) VALUES
(1, 117, '2021-12-19', 0, 'Prepaid', 'NA', 0, 22500, 0, 22500, 1, 1),
(2, 45, '2021-12-18', 0, 'knjhg', 'Yes', 0, 1000, 0, 1000, 2, 1),
(3, 117, '2021-12-18', 0, 'Prepaid', 'No', 0, 18000, 0, 18000, 3, 1),
(4, 117, '2021-12-18', 0, 'Prepaid', 'No', 0, 18000, 0, 18000, 3, 1),
(5, 117, '2021-12-18', 0, 'Prepaid', 'No', 0, 18000, 0, 18000, 3, 1),
(6, 117, '2021-12-18', 0, 'Prepaid', 'No', 0, 18000, 0, 18000, 3, 1),
(7, 1001, '2021-12-18', 0, 'Prepaid', 'No', 0, 18000, 0, 18000, 3, 1),
(8, 1001, '2021-12-18', 0, 'Prepaid', 'No', 0, 18000, 0, 18000, 3, 1),
(9, 1001, '2021-12-18', 0, 'Prepaid', 'No', 0, 18000, 0, 18000, 3, 1),
(10, 1001, '2021-12-18', 0, 'Prepaid', 'No', 0, 18000, 0, 18000, 3, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admintable`
--
ALTER TABLE `admintable`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `customertable`
--
ALTER TABLE `customertable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customertable_vmm`
--
ALTER TABLE `customertable_vmm`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orderdetail`
--
ALTER TABLE `orderdetail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orderno` (`orderno`);

--
-- Indexes for table `orderdetail_vmm`
--
ALTER TABLE `orderdetail_vmm`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ordertable`
--
ALTER TABLE `ordertable`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customerid` (`customerid`);

--
-- Indexes for table `ordertable_vmm`
--
ALTER TABLE `ordertable_vmm`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customertable`
--
ALTER TABLE `customertable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;

--
-- AUTO_INCREMENT for table `customertable_vmm`
--
ALTER TABLE `customertable_vmm`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `orderdetail`
--
ALTER TABLE `orderdetail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `orderdetail_vmm`
--
ALTER TABLE `orderdetail_vmm`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `ordertable`
--
ALTER TABLE `ordertable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;

--
-- AUTO_INCREMENT for table `ordertable_vmm`
--
ALTER TABLE `ordertable_vmm`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orderdetail`
--
ALTER TABLE `orderdetail`
  ADD CONSTRAINT `orderdetail_ibfk_1` FOREIGN KEY (`orderno`) REFERENCES `ordertable` (`id`);

--
-- Constraints for table `ordertable`
--
ALTER TABLE `ordertable`
  ADD CONSTRAINT `ordertable_ibfk_1` FOREIGN KEY (`customerid`) REFERENCES `customertable` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
