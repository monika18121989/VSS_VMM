<?php
@session_start();
include 'connection.php';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>VSS - Index Page</title>
    <?php include 'headerfiles.php'; ?>

</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-12 col-sm-12">
            <div class="col-sm-6 col-6 offset-3 myborder">
                <h1 class="text-primary text-center p-3 pt-5 text-decoration-underline">Veenus Software Soultions</h1>
            <div class="pt-4">
                <h3 class="text-center">Login Here</h3>
                <form id="frmAdminLogin">
                <div class="row p-1">
                    <div class="col-10 col-sm-10 offset-1">
                        <input type="text" name="username" id="username" data-rule-required="true" data-msg-required="Please Enter Username" class="form-control" placeholder="Enter Username">
                    </div>
                </div>
                <div class="row p-1">
                    <div class="col-10 col-sm-10 offset-1">
                        <input type="password" name="password" id="password" data-rule-required="true" data-msg-required="Please Enter Password" class="form-control" placeholder="Enter Password">
                    </div>
                </div>
                <div class="row p-1">
                    <div class="col-3 col-sm-3 offset-1">
                        <input type="button" class="btn btn-outline-primary" value="Login" onclick="checkLogin()">
                    </div>
                </div>
                </form>
                <div class="row pt-2">
                    <div class="col-10 col-sm-10 offset-1">
                        <div id="output"></div>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>