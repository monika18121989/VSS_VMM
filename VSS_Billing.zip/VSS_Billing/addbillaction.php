<?php
include 'cart.php';
include 'connection.php';
@session_start();

$customerid = $_POST['customerid'];
$name = $_POST['name1'];
$address = $_POST['address'];
$city = $_POST['city'];
$state = $_POST['state'];
$country = $_POST['country'];

$invoiceno = $_POST['invoiceno'];
$date = $_POST['date'];
$orderno = $_POST['orderno'];
$payment_terms = $_POST['payment_terms'];
$transfer_rights = $_POST['transfer_rights'];

$total = 0;
//$total = $_POST['total'];
$gtotal = $_POST['gtotal'];
$advance = $_POST['advance'];
$balance = $_POST['balance'];

//$date = strtotime($date);
//$convertedDate = date('Y-m-d',$date);

$convertedDate= DateTime::createFromFormat('d-m-Y', $date)->format('Y-m-d');

echo $convertedDate;

$last_CustomerID = 0;
if($customerid==0)
{
    $qr = "insert into customertable values (null,'$name','$address','$city','$state','$country')";
    $res = mysqli_query($con,$qr);
    $last_CustomerID = mysqli_insert_id($con);
}
else
{
    $last_CustomerID = $customerid;
}


$qr1 = "insert into ordertable values (null,'$invoiceno','$convertedDate','$orderno','$payment_terms','$transfer_rights','$total','$gtotal','$advance','$balance','$last_CustomerID','1')";
echo $qr1;
$res1 = mysqli_query($con,$qr1);
$last_OrderID = mysqli_insert_id($con);

$ar = $_SESSION["products"];
for($i=0;$i<count($ar);$i++) {
    $description = $ar[$i]->description;
    $qty = $ar[$i]->qty;
    $rate = $ar[$i]->rate;
    $total = $ar[$i]->total;
    $qr2 = "insert into orderdetail values (null,'$description','$qty','$rate','$total','$last_OrderID')";
    $res2 = mysqli_query($con,$qr2);
}
echo 1;