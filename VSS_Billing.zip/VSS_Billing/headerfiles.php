

<link href="<?php echo FILESPATH ?>/css/bootstrap.css" rel="stylesheet">
<script src="<?php echo FILESPATH ?>/js/jquery.min.js"></script>
<script src="<?php echo FILESPATH ?>/js/bootstrap.js"></script>
<script src="<?php echo FILESPATH ?>/js/jquery.validate.js"></script>
<script src="<?php echo FILESPATH ?>/myjs/admin.js"></script>
<!--<link rel="stylesheet" href="css/all.min.css"/>-->

<link rel="stylesheet" href="//code.jquery.com/ui/1.13.0/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.13.0/jquery-ui.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
      crossorigin="anonymous" referrerpolicy="no-referrer"/>

<script src="<?php echo FILESPATH ?>/jquery-table2excel-master/src/jquery.table2excel.js"></script>

<style>
    .myborder {
        border: 1px solid #bbbbbb;
        margin-top: 30px;
        padding-bottom: 20px;
        box-shadow: 0px 0px 5px 0px #bbbbbb;
    }

    .error {
        font-size: 11px;
        color: red;
    }
    .form-control
    {
        border-top-style: hidden;
        border-left-style: hidden;
        border-right-style: hidden;
        border-bottom: 1px solid #000000;
        /*background-color: #eeeeee;*/
    }
    .footer{
        position: fixed;
        /*text-align: center;*/
        bottom: 0px;
        width: 100%;
    }

    /*input[type=radio] {*/
    /*    padding: 0.5em;*/
    /*    -webkit-appearance: none;*/
    /*    outline: 0.1em solid black;*/
    /*    outline-offset: 0.1em;*/
    /*}*/

    /*input[type=radio]:checked {*/
    /*    display: inline-block;*/
    /*    background-color: #000;*/
    /*}*/

</style>
