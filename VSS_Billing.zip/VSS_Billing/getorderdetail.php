<?php
include 'connection.php';

if(isset($_REQUEST['orderid']))
{
    $orderid = $_REQUEST['orderid'];
    $qr = "select * from orderdetail where orderno='$orderid'";
}
$res = mysqli_query($con,$qr);
$ar = array();
$num = 0;
while($row = mysqli_fetch_assoc($res))
{
    $ar[$num] = $row;
    $num++;
}
print_r(json_encode($ar));
