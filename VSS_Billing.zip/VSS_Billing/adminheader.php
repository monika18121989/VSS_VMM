
<nav class="navbar navbar-expand-sm navbar-light bg-light" id="navID">
    <div class="container-fluid">
        <a class="navbar-brand" href="adminhomepage.php">VSS</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="mynavbar">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo FILESPATH ?>/adminhomepage.php">Home</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Admin</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="<?php echo FILESPATH ?>/viewadmin.php">View Admins</a></li>
                    </ul>
                </li>
<!--                <li class="nav-item">-->
<!--                    <a class="nav-link" href="--><?php //echo FILESPATH ?><!--/newbill.php">New Bill</a>-->
<!--                </li>-->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">VSS</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="<?php echo FILESPATH ?>/newbill.php">New Bill</a></li>
                        <li><a class="dropdown-item" href="<?php echo FILESPATH ?>/searchbyDate.php">Search Bill</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">VMM</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="<?php echo FILESPATH ?>/vmm/newbill.php">New Bill</a></li>
                        <li><a class="dropdown-item" href="<?php echo FILESPATH ?>/vmm/searchbyDate.php">Search Bill</a></li>
                    </ul>
                </li>
            </ul>
            <form class="d-flex">
                <a href="<?php echo FILESPATH ?>/adminlogout.php" class="btn btn-primary">Logout</a>
            </form>
        </div>
    </div>
</nav>
