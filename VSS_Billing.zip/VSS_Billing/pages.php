<html>
<head>
    <title>Pagination</title>
    <!-- Bootstrap CDN -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<?php
    $i = 1;
    $s = "";
    $s.= "<table class='table table-striped table-bordered' style='border: 1px solid #000;'>";
    $s.=  "<thead>";
    $s.=  "<th width='5%'>Srno</th>";
    $s.=  "<th>Invoice No</th>";
    $s.=  "<th>Date</th>";
    $s.=  "<th>Payment Terms</th>";
    $s.=  "<th>Total</th>";
    $s.=  "<th>Advance</th>";
    $s.=  "<th>Balance</th>";
    $s.=  "</thead>";
if (isset($_GET['pageno'])) {
    $pageno = $_GET['pageno'];
} else {
    $pageno = 1;
}
$no_of_records_per_page = 10;
$offset = ($pageno-1) * $no_of_records_per_page;
include 'connection.php';

$total_pages_sql = "SELECT COUNT(*) FROM ordertable";
$result = mysqli_query($con,$total_pages_sql);
$total_rows = mysqli_fetch_array($result)[0];
$total_pages = ceil($total_rows / $no_of_records_per_page);

$sql = "SELECT * FROM ordertable LIMIT $offset, $no_of_records_per_page";
$res_data = mysqli_query($con,$sql);
while($row = mysqli_fetch_array($res_data)){

        $s.= "<tr>";
        $s.=  "<th>" .($i). "</th>";
        $s.= "<td>". $row['invoiceno'] ."</td>";
        $s.=  "<td>". $row['dated'] ."</td>";
        $s.=  "<td>". $row['payment_terms'] ."</td>";
        $s.=  "<td>". $row['grandtotal'] ."</td>";
        $s.=  "<td>". $row['advance'] ."</td>";
        $s.= "<td>". $row['balance'] ."</td>";
        $s.= "</tr>";
        $i=$i+1;
}
mysqli_close($con);
$s.=  "</table>";
echo $s;
?>
<ul class="pagination">
    <li><a href="?pageno=1">First</a></li>
    <li class="<?php if($pageno <= 1){ echo 'disabled'; } ?>">
        <a href="<?php if($pageno <= 1){ echo '#'; } else { echo "?pageno=".($pageno - 1); } ?>">Prev</a>
    </li>
    <li class="<?php if($pageno >= $total_pages){ echo 'disabled'; } ?>">
        <a href="<?php if($pageno >= $total_pages){ echo '#'; } else { echo "?pageno=".($pageno + 1); } ?>">Next</a>
    </li>
    <li><a href="?pageno=<?php echo $total_pages; ?>">Last</a></li>
</ul>
</body>
</html>