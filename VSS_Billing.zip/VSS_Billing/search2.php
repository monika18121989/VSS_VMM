<?php
include'connection.php';
?>

<!doctype html>
<html>
<head>
    <title>Datatable AJAX pagination with PHP and PDO</title>
    <!-- Datatable CSS -->
    <?php include 'headerfiles.php'; ?>
    <link href='DataTables/datatables.min.css' rel='stylesheet' type='text/css'>

    <!-- jQuery Library -->
<!--    <script src="jquery-3.3.1.min.js"></script>-->

    <!-- Datatable JS -->
    <script src="DataTables/datatables.min.js"></script>

</head>
<body >

<div class="container">
    <?php include 'adminheader.php'; ?>
    <!-- Table -->
    <div class="mt-5 mb-3">
        <h2 class="text-center">Search Bill</h2>
    </div>
    <table id='orderTable' class='display dataTable'>
        <thead>
        <tr>
            <th></th>
            <th>ID</th>
            <th>Name</th>
            <th>Invoice No</th>
            <th data-orderable="false">Total</th>           <!-- remove sort buttons -->
            <th>Advance</th>
            <th>Balance</th>
            <th>Action</th>
        </tr>
        </thead>

    </table>
</div>
<!-- Script -->
<script>
    $(document).ready(function(){
        var i = 1;
        var t = $('#orderTable').DataTable({
            'processing': true,
            'serverSide': true,
            'serverMethod': 'post',
            'ajax': {
                'url':'ajaxfile2.php'
            },
            'columns': [
                { data: 'srno' },
                { data: 'id' },
                { data: 'name' },
                { data: 'invoiceno' },
                { data: 'grandtotal' },
                { data: 'advance' },
                { data: 'balance' },
                {
                    data: null,                                   // add button to DataTable
                    render: function (data, type, row) {
                        return '<a onclick="open_MdlOrderDetail('+data['id']+')" class="btn btn-outline-info btn-sm">View Detail</a>';
                    }
                }
            ],
            "columnDefs":[
                {"bSortable":false,"aTargets":[7]},     // remove sort on 'action' column (column index - 7)
                {"bSearchable":false,"aTargets":[7]},  // remove search on 'action' column (column index - 7)
                {"bSearchable":false,"bSortable":false,"aTargets": [0] },
                {"visible":false,"aTargets":[1]}
            ],
            "order": [[ 1, 'asc' ]]
        });
        // t.draw();
    });
</script>

<!-- The Modal (Order Detail)-->
<div class="modal fade" id="mdl_OrderDetail">
    <div class="modal-dialog">
        <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title">Order Detail (<span id="orderid"></span>)</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <!-- Modal body -->
            <div class="modal-body">
                <div class="col-12 col-sm-12">
                    <div id="output_OrderDetail"></div>
                </div>
            </div>

            <!-- Modal footer -->
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
            </div>

        </div>
    </div>
</div>
<!-- The Modal (Order Detail)-->

</body>

</html>
