<?php
@session_start();
include 'connection.php';
$ar = array();
$num = 0;
if(isset($_REQUEST['cname']))
{
    $cname = $_REQUEST['cname'];
    $qr = "select ordertable.*,customertable.name,customertable.address from ordertable,customertable where ordertable.customerid=customertable.id and customertable.name LIKE '%$cname%'";
//    echo $qr;
    $res = mysqli_query($con,$qr);
    while($row = mysqli_fetch_assoc($res))
    {
        $ar[$num] = $row;
        $num++;
    }
}

if(isset($_REQUEST['datefrom']) && isset($_REQUEST['dateto']))
{
    $datefrom = date('Y-m-d',strtotime($_REQUEST['datefrom']));
    $dateto = date('Y-m-d',strtotime($_REQUEST['dateto']));
    $qr = "select ordertable.*,customertable.name,customertable.address from ordertable,customertable where ordertable.customerid=customertable.id and dated BETWEEN '$datefrom' AND '$dateto'";
//    echo $qr;
    $res = mysqli_query($con,$qr);
    while($row = mysqli_fetch_assoc($res))
    {
        $ar[$num] = $row;
        $num++;
    }
}

print_r(json_encode($ar));