<?php

include 'connection.php';
date_default_timezone_set('Asia/Kolkata');
$data = json_decode($_REQUEST['q'], true);
//print_r($data);
$username = $data['username'];
$fullname = $data['fullname'];
$admintype = $data['admintype'];
//$dt = date('y-m-d');
//$tm = date('H:i');

$qr = "update admintable set fullname='$fullname',admintype='$admintype' where username='$username'";
$result = mysqli_query($con, $qr);
if($result) {
//    echo $qr;
    echo 1;
}
else
{
    echo 2;
}

?>