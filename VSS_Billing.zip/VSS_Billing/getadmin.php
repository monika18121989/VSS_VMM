<?php
include 'connection.php';

if(isset($_REQUEST['username']))
{
    $username = $_REQUEST['username'];
    $qr = "select * from admintable where username='$username'";
}
else {
    $qr = "select * from admintable order by username";
}
$res = mysqli_query($con,$qr);
$ar = array();
$num = 0;
while($row = mysqli_fetch_assoc($res))
{
    $ar[$num] = $row;
    $num++;
}
print_r(json_encode($ar));
