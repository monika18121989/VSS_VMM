var FLAG = false;
$(document).ready(function(){
    $("form").validate();
})

function getCustomerInfo()
{
    var cname = document.getElementById('name1').value;
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function(){
        if(this.readyState==4 && this.status==200)
        {
            var ar = JSON.parse(this.response);
            console.log(ar.length + ' -------');
            if(ar.length>0)
            {
                document.getElementById('customerid').value = ar[0]['id'];
                document.getElementById('address').value = ar[0]['address'];
                document.getElementById('city').value = ar[0]['city'];
                document.getElementById('state').value = ar[0]['state'];
                document.getElementById('country').value = ar[0]['country'];
            }
            else
            {
                document.getElementById('customerid').value = 0;
                document.getElementById('address').value = "";
                document.getElementById('city').value = "";
                document.getElementById('state').value = "";
                document.getElementById('country').value = "";
            }
        }
    };
    xmlhttp.open('GET','getcustomer.php?cname='+cname,true);
    xmlhttp.send();
}

function addToCart()
{
    var controls = document.getElementById('frm_Items').elements;

    var formdata = new FormData();
    for(var i=0;i<controls.length-1;i++)
    {
        formdata.append(controls[i].name, controls[i].value);
    }

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function ()
    {
        if(this.readyState==4 && this.status==200)
        {
            console.log(this.response);
            var ar = JSON.parse(this.response);
            showCartinTable(ar);

            document.getElementById('frm_Items').reset();
            // document.getElementById('descp1').value = "";
            // document.getElementById('qty1').value = "";
            // document.getElementById('rate1').value = "";
            // document.getElementById('total1').value = "";
            document.getElementById('descp1').focus();
            FLAG = true;
        }
    };
    xmlhttp.open('POST','add_to_cart.php',true);
    xmlhttp.send(formdata);
}

function showCartinTable(ar)
{
var s = "";
s += "<table class='table table-striped table-bordered' style='border: 1px solid #000;'>";
s += "<thead>";
s += "<th width='5%'>Srno</th>";
s += "<th>Description</th>";
s += "<th width='15%'>Qty/Man Hours</th>";
s += "<th width='15%'>Rate</th>";
s += "<th width='15%'>Total</th>";
s += "<th width='5%' class='PDF'></th>";
s += "</thead>";

for(var i=0;i<ar.length;i++)
{
    s += "<tr>";
    s += "<th>" +(i+1)+ "</th>";
    s += "<td>"+ ar[i]['description'] +"</td>";
    s += "<td>"+ ar[i]['qty'] +"</td>";
    s += "<td>"+ ar[i]['rate'] +"</td>";
    s += "<td>"+ ar[i]['total'] +"</td>";
    s += "<td class='PDF'><a onclick='deletefromCart(" + ar[i]['rowid'] + ")' class='btn btn-danger btn-sm'><span class='fa fa-trash'></span></a></td>";
    s += "</tr>";
}

s += "</table>";

document.getElementById('div_CartItems').innerHTML = s;
}

function deletefromCart(rowid)
{
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function (){
        if(this.readyState==4 && this.status==200)
        {
            console.log(this.response);
            var ar = JSON.parse(this.response);
            showCartinTable(ar);
        }
    };
    xmlhttp.open('GET','deletefromCart.php?rowid=' + rowid,true);
    xmlhttp.send();
}


function generateBill()
{
    if ($("#frm_Customer").valid() && $("#frm_Invoice").valid() && $("#frm_Terms").valid())  {
        var controls = document.getElementById('frm_Customer').elements;

        var formdata = new FormData();
        for(var i=0;i<controls.length;i++)
        {
            formdata.append(controls[i].name, controls[i].value);
        }

        var invoiceno = document.getElementById('invoiceno').value;
        var date = document.getElementById('dated').value;
        var orderno = document.getElementById('orderno').value;
        var payment_terms = document.getElementById('payment_terms').value;

        var transfer_rights="";
        if(document.getElementById('trans_rgt_Yes').checked == true)
        {
            transfer_rights = "Yes";
        }
        else if(document.getElementById('trans_rgt_No').checked == true)
        {
            transfer_rights = "No";
        }
        else
        {
            transfer_rights = "NA";
        }
        // var total = document.getElementById('total').value;
        var gtotal = document.getElementById('gtotal').value;
        var advance = document.getElementById('advance').value;
        var balance = document.getElementById('balance').value;

        formdata.append("invoiceno",invoiceno);
        formdata.append("date",date);
        formdata.append("orderno",orderno);
        formdata.append("payment_terms",payment_terms);
        formdata.append("transfer_rights",transfer_rights);
        // formdata.append("total",total);
        formdata.append("gtotal",gtotal);
        formdata.append("advance",advance);
        formdata.append("balance",balance);

        if(FLAG == false)
        {
            alert("Please add item in list");
        }
        else
        {
            var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function ()
            {
                if(this.readyState==4 && this.status==200)
                {
                    var output = this.responseText;
                    console.log(output);
                    printDiv();
                }
            };
            xmlhttp.open('POST','addbillaction.php',true);
            xmlhttp.send(formdata);
        }
    }
}

function printDiv() {
    // document.getElementById('div_Items').style.display = "none";
    // var printContents = document.getElementById('printPage').innerHTML;
    // var originalContents = document.body.innerHTML;
    //
    // document.body.innerHTML = printContents;
    var controls = document.getElementById('frm_Customer').elements;
    for (var i = 0; i < controls.length; i++){
        controls[i].style.borderBottom = 'hidden';
    }
    document.getElementById('invoiceno').style.borderBottom = 'hidden';
    document.getElementById('dated').style.borderBottom = 'hidden';
    document.getElementById('orderno').style.borderBottom = 'hidden';
    document.getElementById('payment_terms').style.borderBottom = 'hidden';
    // document.getElementById('total').style.borderBottom = 'hidden';
    document.getElementById('gtotal').style.borderBottom = 'hidden';
    document.getElementById('advance').style.borderBottom = 'hidden';
    document.getElementById('balance').style.borderBottom = 'hidden';
    document.getElementById('div_Items').style.display = "none";
    document.getElementById('btn_bill').style.display = "none";
    document.getElementById('navID').style.display = "none";
    $('.PDF').hide();

    window.print();

    window.location.href = "newbill.php";

    // document.body.innerHTML = originalContents;
}

function showBillbyName()
{
    var cname = document.getElementById('searchcname').value;
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function (){
      if(this.readyState==4 && this.status==200)
      {
          console.log(this.response);
          var ar = JSON.parse(this.response);
          OrderResultinTable(ar);
      }
    };
    xmlhttp.open('GET','searchbillaction.php?cname='+cname,true);
    xmlhttp.send();
}

function showBillbyDate()
{
    var datefrom = document.getElementById('datefrom').value;
    var dateto = document.getElementById('dateto').value;
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function (){
        if(this.readyState==4 && this.status==200)
        {
            console.log(this.response);
            var ar = JSON.parse(this.response);
            OrderResultinTable(ar);
        }
    };
    xmlhttp.open('GET','searchbillaction.php?datefrom='+datefrom + '&dateto=' + dateto,true);
    xmlhttp.send();
}

function OrderResultinTable(ar)
{
    var s = "";
    s += "<table class='table display dataTable' id='table_id' style='border: 1px solid #000;'>";
    s += "<thead>";
    s += "<th width='5%'>Srno</th>";
    s += "<th>Customer Name</th>";
    s += "<th>Address</th>";
    s += "<th>Date</th>";
    s += "<th>Payment Terms</th>";
    s += "<th>Total</th>";
    s += "<th>Advance</th>";
    s += "<th>Balance</th>";
     s += "</thead>";

    for(var i=0;i<ar.length;i++)
    {
        s += "<tr>";
        s += "<th>" +(i+1)+ "</th>";
        s += "<td>"+ ar[i]['name'] +"</td>";
        s += "<td>"+ ar[i]['address'] +"</td>";
        s += "<td>"+ ar[i]['dated'] +"</td>";
        s += "<td>"+ ar[i]['payment_terms'] +"</td>";
        s += "<td>"+ ar[i]['grandtotal'] +"</td>";
        s += "<td>"+ ar[i]['advance'] +"</td>";
        s += "<td>"+ ar[i]['balance'] +"</td>";
        s += "<td><button type='button' class='btn btn-sm btn-secondary' onclick='open_MdlOrderDetail("+ ar[i]['id'] +")'>View Details</button></td>";
        s += "</tr>";
    }

    s += "</table>";

    document.getElementById('output').innerHTML = s;
    $('#table_id').DataTable();
}

function open_MdlOrderDetail(orderid)
{
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function (){
        if(this.readyState==4 && this.status==200)
        {
            console.log(this.response);
            var ar = JSON.parse(this.response);
            document.getElementById('orderid').innerHTML = "ID- " + orderid;
            OrderDetailResultinTable(ar);
            $('#mdl_OrderDetail').modal('show');
        }
    };
    xmlhttp.open('GET','getorderdetail.php?orderid='+orderid,true);
    xmlhttp.send();
}

function OrderDetailResultinTable(ar)
{
    var s = "";
    s += "<table class='table table-striped table-bordered' style='border: 1px solid #000;'>";
    s += "<thead>";
    s += "<th width='5%'>Srno</th>";
    s += "<th>Description</th>";
    s += "<th width='15%'>Qty/Man Hours</th>";
    s += "<th width='15%'>Rate</th>";
    s += "<th width='15%'>Total</th>";
    s += "</thead>";

    for(var i=0;i<ar.length;i++)
    {
        s += "<tr>";
        s += "<th>" +(i+1)+ "</th>";
        s += "<td>"+ ar[i]['descp1'] +"</td>";
        s += "<td>"+ ar[i]['qty'] +"</td>";
        s += "<td>"+ ar[i]['rate'] +"</td>";
        s += "<td>"+ ar[i]['total'] +"</td>";
        s += "</tr>";
    }

    s += "</table>";

    document.getElementById('output_OrderDetail').innerHTML = s;
}