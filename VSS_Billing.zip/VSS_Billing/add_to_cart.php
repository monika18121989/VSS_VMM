<?php
include "cart.php";
include 'connection.php';
@session_start();

$ar = array();
$arno = 0;

if (isset($_SESSION['products'])) {
    $ar = $_SESSION['products'];
    if($_POST['rate1']=="")
    {
        $rate1 = 0;
    }
    else
    {
        $rate1 = $_POST['rate1'];
    }
    $ar[count($ar)] = new cart($_POST['descp1'], $_POST['qty1'], $rate1,$_POST['total1'],(count($ar)+1));
    $_SESSION['products'] = $ar;
}
else {
    if($_POST['rate1']=="")
    {
        $rate1 = 0;
    }
    else
    {
        $rate1 = $_POST['rate1'];
    }
    $ar[0] = new cart($_POST['descp1'], $_POST['qty1'], $rate1,$_POST['total1'],1);

    $_SESSION['products'] = $ar;
//        var_dump($ar);
}
echo json_encode($ar);