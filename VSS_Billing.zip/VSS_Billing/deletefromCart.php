<?php
include "cart.php";
@session_start();
$rowid=$_REQUEST['rowid'];
$ar = $_SESSION['products'];
$new_ar=array();
$count=0;
for ($i = 0; $i < count($ar); $i++) {
    if($rowid!=$ar[$i]->rowid)
    {
        $new_ar[$count]=$ar[$i];
        $count++;
    }
}
$_SESSION['products']=$new_ar;
echo json_encode($new_ar);