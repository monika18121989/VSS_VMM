<?php

class cart
{
    public  $description, $qty, $rate, $total,$rowid;

    public function __construct( $description, $qty, $rate, $total,$rowid)
    {
        $this->description = $description;
        $this->qty = $qty;
        $this->rate = $rate;
        $this->total = $total;
        $this->rowid = $rowid;
    }
}