<?php

define("FILESPATH",'http://'.$_SERVER['HTTP_HOST'].'/VSS_Billing');

$con = mysqli_connect("localhost","root",null,"vss_bill");
if(!($con))
{
    die("<div class='col-md-10 col-md-offset-1'><h1 class='text-center text-danger'>Could Not Connect to Server. Please Connect to your Administrator.</h1></div>");
}