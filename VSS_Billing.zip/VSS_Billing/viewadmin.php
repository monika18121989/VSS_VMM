<?php
@session_start();
if(!isset($_SESSION['ADMIN']))
{
    header("Location:index.php");
}
include 'connection.php';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>VSS - Admin</title>
    <?php include 'headerfiles.php'; ?>
<!--    --><?php //include 'myjs/admin.js'; ?>
    <script>
        setTimeout(function(){
            $("#msgdiv").fadeOut(400);
        }, 5000)
    </script>
</head>
<body onload="showAdmins()">
<div class="container">
    <?php include 'adminheader.php'; ?>

    <div class="row">
        <div class="col-sm-6 offset-3">

        </div>
    </div>

    <div class="row">
        <div class="col-12 col-sm-12">
                <div class="pt-4">
                    <div class="row pt-2">
                        <div class="col-10 col-sm-10 offset-1">
                            <div class="text-end">
                                <button type="button" onclick="openAddAdminModel()" class="btn btn-outline-secondary btn-sm m-2">Add New Admin</button>
                            </div>
                            <h1 class='head1 text-center'>Admin List</h1>
                            <div class="row">
                                <div class="col-sm-4 col-4 offset-4">
                                    <div class="text-center" id="msgdiv">
                                        <?php
                                        if(isset($_REQUEST['upd']))
                                        {
                                            if($_REQUEST['upd']==101)
                                            {
                                                echo '<div class="badge bg-success">Delete Successful</div>';
                                            }
                                            else
                                            {
                                                echo '<div class="badge bg-danger">Something went wrong. Try again</div>';
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                                <div class="col-sm-4 col-4 text-end">
                                    <span id="excelExport" class="text-success" style="cursor: pointer;font-size: 20px;" title="Export to Excel"><i class="fas fa-file-excel" aria-hidden="true"></i></span>
                                </div>
                            </div>

                            <div id="output"></div>
                        </div>
<!--                        <button type="button" id="dataExport" class="col-2 col-sm-2 btn btn-primary">Excel</button>-->
<!--                        <a href="excel_demo.php">XLS</a>-->
                    </div>
                </div>
        </div>
    </div>

</div>

<!-- The Modal (Add Admin)-->
<div class="modal fade" id="mdl_AddAdmin">
    <div class="modal-dialog">
        <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title">Add Admin</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <!-- Modal body -->
            <div class="modal-body">
                <form id="frm_AddAdmin">
                    <div class="col-12 col-sm-12">
                        <div class="row p-1">
                            <div class="col-3">
                                <label class="fw-bold">Username</label>
                            </div>
                            <div class="col-9">
                                <input type="text" name="username" placeholder="Enter Username" id="username" class="form-control"
                                       data-rule-required="true" data-msg-required="*">
                            </div>
                        </div>
                        <div class="row p-1">
                            <div class="col-3">
                                <label class="fw-bold">Password</label>
                            </div>
                            <div class="col-9">
                                <input type="password" name="password" placeholder="Enter Password"  id="password" class="form-control"
                                       data-rule-required="true" data-msg-required="*">
                            </div>
                        </div>
                        <div class="row p-1">
                            <div class="col-3">
                                <label class="fw-bold">Confirm Password</label>
                            </div>
                            <div class="col-9">
                                <input type="password" name="cpassword" placeholder="Confirm Password"  id="cpassword" class="form-control"
                                       data-rule-required="true" data-msg-required="*" data-rule-equalto="#password" data-msg-equalto="Mismatch Password">
                            </div>
                        </div>
                        <div class="row p-1">
                            <div class="col-3">
                                <label class="fw-bold">Fullname</label>
                            </div>
                            <div class="col-9">
                                <input type="text" name="fullname" placeholder="Enter Fullname" id="fullname" class="form-control"
                                       data-rule-required="true" data-msg-required="*">
                            </div>
                        </div>
                        <div class="row p-1">
                            <div class="col-3">
                                <label class="fw-bold">Type</label>
                            </div>
                            <div class="col-9">
                                <select name="admintype" id="admintype" class="form-control"
                                       data-rule-required="true" data-msg-required="*">
                                    <option value="">-- Select Admin Type --</option>
                                    <option value="Administrator">Administrator</option>
                                    <option value="Super User">Super User</option>
                                </select>
                            </div>
                        </div>
                        <div class="row p-1">
                            <div class="col-3 offset-3">
                                <button type="button" onclick="addAdmin()" class="btn btn-success">Submit</button>
                            </div>
                        </div>
                        <div class="row p-1">
                            <div class="col-6 offset-3">
                                <div id="er1"></div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Modal footer -->
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
            </div>

        </div>
    </div>
</div>
<!-- The Modal (Add Admin)-->

<!-- The Modal (Edit Admin)-->
<div class="modal fade" id="mdl_EditAdmin">
    <div class="modal-dialog">
        <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title">Edit Admin</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <!-- Modal body -->
            <div class="modal-body">
                <form id="frm_EditAdmin">
                    <div class="col-12 col-sm-12">
                        <div class="row p-1">
                            <div class="col-3">
                                <label class="fw-bold">Username</label>
                            </div>
                            <div class="col-9">
                                <input type="text" name="edt_username" readonly id="edt_username" class="form-control"
                                       data-rule-required="true" data-msg-required="*">
                            </div>
                        </div>

                        <div class="row p-1">
                            <div class="col-3">
                                <label class="fw-bold">Fullname</label>
                            </div>
                            <div class="col-9">
                                <input type="text" name="edt_fullname" placeholder="Enter Fullname" id="edt_fullname" class="form-control"
                                       data-rule-required="true" data-msg-required="*">
                            </div>
                        </div>
                        <div class="row p-1">
                            <div class="col-3">
                                <label class="fw-bold">Type</label>
                            </div>
                            <div class="col-9">
                                <select name="edt_admintype" id="edt_admintype" class="form-control"
                                       data-rule-required="true" data-msg-required="*">
                                    <option value="">-- Select Admin Type --</option>
                                    <option value="Administrator">Administrator</option>
                                    <option value="Super User">Super User</option>
                                </select>
                            </div>
                        </div>
                        <div class="row p-1">
                            <div class="col-3 offset-3">
                                <button type="button" onclick="editAdmin()" class="btn btn-success">Update</button>
                            </div>
                        </div>
                        <div class="row p-1">
                            <div class="col-6 offset-3">
                                <div id="er2"></div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Modal footer -->
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
            </div>

        </div>
    </div>
</div>
<!-- The Modal (Edit Admin)-->

<script src="tableExport/tableExport.js"></script>
<script type="text/javascript" src="tableExport/jquery.base64.js"></script>
<script>
    $( document ).ready(function() {
        $("#excelExport").click(function() {

            $("#abc").table2excel({
                name: "Backup file for HTML content",

                //  include extension also
                filename: "AdminData.xls",

                // 'True' is set if background and font colors preserved
                preserveColors: false
            });



            // var exportType = "excel";
            // $('#dataTable').tableExport({
            //     type : exportType,
            //     escape : 'false',
            //     ignoreColumn: []
            // });
        });
    });
</script>
</body>
</html>