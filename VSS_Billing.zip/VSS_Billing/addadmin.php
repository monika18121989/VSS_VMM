<?php

include 'connection.php';
date_default_timezone_set('Asia/Kolkata');
$data = json_decode($_REQUEST['q'], true);
//print_r($data);
$username = $data['username'];
$password = $data['password'];
$fullname = $data['fullname'];
$admintype = $data['admintype'];
$dt = date('y-m-d');
$tm = date('H:i');


$s = "select * from admintable WHERE username='$username'";

$result = mysqli_query($con, $s);
if (mysqli_num_rows($result) > 0) {
    echo 1;
}
else
{
    $qr = "insert into admintable values ('$username','$password','$fullname','$admintype','$dt','$tm','1')";
    mysqli_query($con, $qr);
    if($result) {
        echo 2;
    }
    else
    {
        echo 3;
    }
}
?>