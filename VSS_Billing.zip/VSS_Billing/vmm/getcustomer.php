<?php
include '../connection.php';

if(isset($_REQUEST['cname']))
{
    $cname = $_REQUEST['cname'];
    $qr = "select * from customertable_vmm where name='$cname'";
}
else {
    $qr = "select * from customertable_vmm order by cname";
}
$res = mysqli_query($con,$qr);
$ar = array();
$num = 0;
while($row = mysqli_fetch_assoc($res))
{
    $ar[$num] = $row;
    $num++;
}
print_r(json_encode($ar));
