<?php
@session_start();
include '../connection.php';
if(!isset($_SESSION['ADMIN']))
{
    header("Location:../index.php");
}
?>
<!doctype html>
<html>
<head>
    <title>Datatable AJAX pagination with PHP and PDO</title>
    <!-- Datatable CSS -->
    <?php include '../headerfiles.php'; ?>
    <script src="myjs/order_vmm.js"></script>
    <link href='../DataTables/datatables.min.css' rel='stylesheet' type='text/css'>

    <!-- jQuery Library -->
<!--    <script src="jquery-3.3.1.min.js"></script>-->

    <!-- Datatable JS -->
    <script src="../DataTables/datatables.min.js"></script>

</head>
<body >

<div class="container">
    <?php include '../adminheader.php'; ?>
    <!-- Table -->
    <div class="mt-5 mb-3 col-12 col-sm-12">
        <h2 class="text-center">Search Bill</h2>
    </div>
    <div class="col-12 col-sm-12">
        <div class="row p-2">
            <div class="col-2 col-sm-2 offset-4">
                <input type="text" placeholder="Start Date" name="datefrom" id="datefrom" class="form-control datepicker">
            </div>
            <div class="col-2 col-sm-2">
                <input type="text" placeholder="End Date" name="dateto" id="dateto" class="form-control datepicker">
            </div>
            <div class="col-sm-1 col-1">
                <button type="button" class="btn btn-warning" id="btn_search">Search</button>
            </div>
            <div class="col-sm-3 col-3 text-end">
                <span id="excelExport" class="text-success" style="cursor: pointer;font-size: 20px;" title="Export to Excel"><i class="fas fa-file-excel" aria-hidden="true"></i></span>
            </div>
        </div>
        <div class="text-center mt-3" id="msgdiv">
            <?php
            if(isset($_REQUEST['upd']))
            {
                if($_REQUEST['upd']==101)
                {
                    echo '<div class="badge bg-success">Delete Successful</div>';
                }
                else
                {
                    echo '<div class="badge bg-danger">Something went wrong. Try again</div>';
                }
            }
            ?>
        </div>
    </div>
    <table id='orderTable' class='display dataTable'>
        <thead>
        <tr>
            <th></th>
            <th>ID</th>
            <th>Name</th>
            <th>Invoice No</th>
            <th data-orderable="false">Total</th>           <!-- remove sort buttons -->
            <th>Advance</th>
            <th>Balance</th>
            <th>Date</th>
            <th>Action</th>
        </tr>
        </thead>

    </table>
</div>
<!-- Script -->
<script>
    $(document).ready(function(){

        // Datapicker
        $( ".datepicker" ).datepicker({
            "dateFormat": "dd-mm-yy",
            changeYear: true
        });

        var i = 1;
        var t = $('#orderTable').DataTable({
            'processing': true,
            'serverSide': true,
            'serverMethod': 'post',
            'searching': true, // Set false to remove default Search Control
            'ajax': {
                'url':'ajaxfile3.php',
                'data': function(data){
                    // Read values
                    var from_date = $('#datefrom').val();
                    var to_date = $('#dateto').val();

                    // Append to data
                    data.searchByFromdate = from_date;
                    data.searchByTodate = to_date;
                }
            },
            'columns': [
                { data: 'srno' },
                { data: 'id' },
                { data: 'name' },
                { data: 'invoiceno' },
                { data: 'grandtotal' },
                { data: 'advance' },
                { data: 'balance' },
                { data: 'dated' },
                {
                    data: null,                                   // add button to DataTable
                    render: function (data, type, row) {
                        return '<a onclick="open_MdlOrderDetail('+ data['id'] +')" class="btn btn-outline-info btn-sm">View Detail</a>' +
                            ' <a href="<?php echo FILESPATH ?>/vmm/deletebill.php?orderid='+ data['id'] +'" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></a>';
                    }
                }
            ],
            "columnDefs":[
                {"bSortable":false,"aTargets":[8]},     // remove sort on 'action' column (column index - 8, starting from 0,as 'id' is hidden)
                {"bSearchable":false,"aTargets":[8]},  // remove search on 'action' column (column index - 8, starting from 0,as 'id' is hidden)
                {"bSearchable":false,"bSortable":false,"aTargets": [0] },
                {"visible":false,"aTargets":[1]}
            ],
            "order": [[ 1, 'asc' ]]
        });
        // Search button
        $('#btn_search').click(function(){
            t.draw();
        });


        $("#excelExport").click(function() {

            $("#orderTable").table2excel({
                name: "Backup file for HTML content",

                //  include extension also
                filename: "OrderHistoryVMM.xls",

                // 'True' is set if background and font colors preserved
                preserveColors: false
            });
        });

    });

    setTimeout(function(){
        $("#msgdiv").fadeOut(400);
    }, 5000)


</script>

<!-- The Modal (Order Detail)-->
<div class="modal fade" id="mdl_OrderDetail">
    <div class="modal-dialog">
        <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title">Order Detail (<span id="orderid"></span>)</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <!-- Modal body -->
            <div class="modal-body">
                <div class="col-12 col-sm-12">
                    <div id="output_OrderDetail"></div>
                </div>
            </div>

            <!-- Modal footer -->
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
            </div>

        </div>
    </div>
</div>
<!-- The Modal (Order Detail)-->

</body>

</html>
