function checkLogin()
{
    if ($("form").valid()) {
        var username = document.getElementById('username').value;
        var password = document.getElementById('password').value;

        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function (){
            if(this.readyState==4 && this.status==200)
            {
                var output = this.responseText;
                console.log(output);
                if (output == 1) {
                    document.getElementById('output').innerHTML = 'Incorrect Username or InActive User';
                    document.getElementById('output').className = 'text-danger';
                }
                else if (output == 2) {
                    document.getElementById('output').innerHTML = 'Incorrect Password';
                    document.getElementById('output').className = 'text-danger';
                }
                else if (output == 3){
                    window.location.href = "adminhomepage.php";
                }
            }
        };
        xmlhttp.open('GET','adminloginaction.php?username=' + username + '&password=' + password,true);
        xmlhttp.send();
    }
}

function showAdmins()
{
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function(){
        if(this.readyState==4 && this.status==200)
        {
            var obj = JSON.parse(this.response);
            showDatainTable(obj);
        }
    };
    xmlhttp.open('GET','getadmin.php',true);
    xmlhttp.send();
}

function showDatainTable(obj)
{
    var s = "<table class='table table-striped'>" +
        "<tr>" +
        "<th class='rowheading'>Sr No</th>" +
        "<th class='rowheading'>Username</th>" +
        "<th class='rowheading'>Fullname</th>" +
        "<th class='rowheading'>Admin Type</th>" +
        "<th class='rowheading'>Login Date</th>" +
        "<th class='rowheading'>Login Time</th>" +
        "<th class='rowheading' colspan='2'>Controls</th>" +
        "</tr>";
    var k = 0;
    // alert(obj.length());
    for (var i = 0; i <= obj.length - 1; i++) {
        ++k;
        var ar = obj[i];
       if(ar['status']==1)
       {
           s = s + "<tr>";
       }
       else
       {
           s = s + "<tr class='bg-danger text-light'>";
       }

        s = s + "<th class='rowheading text-center'>" + k + "</th>";
        s = s + "<td>" + ar["username"] + "</td>";
        s = s + "<td>" + ar["fullname"] + "</td>";
       s = s + "<td>" + ar["admintype"] + "</td>";
        s = s + "<td>" + ar["dateoflogin"] + "</td>";
        s = s + "<td>" + ar["timeoflogin"] + "</td>";
        s = s + "<td><i class='fas fa-edit' style='cursor: pointer;' onclick=openEditAdminModel('"+ ar['username'] +"')></i></td>";
        s = s + "<td><a href='deleteadmin.php?username=" + ar["username"] + "' onclick='return confirm(\"Are your Sure You want to Delete?\")'><i class='fas fa-trash'></i></a></td>";

        s = s + "</tr>";
    }
    s = s + "</table>";
    document.getElementById("output").innerHTML = s;
}

function openAddAdminModel()
{
    $('#mdl_AddAdmin').modal('show');
}

function addAdmin()
{
    if ($("#frm_AddAdmin").valid()) {
        var username = document.getElementById('username').value;
        var password = document.getElementById('password').value;
        var fullname = document.getElementById('fullname').value;
        var admintype = document.getElementById('admintype').value;

        var s = {
            username:username,
            password:password,
            fullname:fullname,
            admintype:admintype
        };

        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function (){
            if(this.readyState==4 && this.status==200)
            {
                var output = this.responseText;
                console.log(output);
                if (output == 1) {
                    document.getElementById('er1').innerHTML = 'Username already exists';
                    document.getElementById('er1').className = 'text-danger';
                }
                else if (output == 3) {
                    document.getElementById('er1').innerHTML = 'Something went wrong. Try again';
                    document.getElementById('er1').className = 'text-danger';
                }
                else if (output == 2){
                    window.location.href = "viewadmin.php";
                }
            }
        };
        xmlhttp.open('GET','addadmin.php?q=' + JSON.stringify(s),true);
        xmlhttp.send();
    }
}

function openEditAdminModel(username)
{
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function(){
        if(this.readyState==4 && this.status==200)
        {
            console.log(this.response);
            var obj = JSON.parse(this.response);
            document.getElementById('edt_username').value = username;
            document.getElementById('edt_fullname').value = obj[0]['fullname'];
            document.getElementById('edt_admintype').value = obj[0]['admintype'];
            document.getElementById('er2').innerHTML="";
            $('#mdl_EditAdmin').modal('show');

        }
    };
    xmlhttp.open('GET','getadmin.php?username=' + username,true);
    xmlhttp.send();
}

function editAdmin()
{
    if ($("#frm_EditAdmin").valid()) {
        var username = document.getElementById('edt_username').value;
        var fullname = document.getElementById('edt_fullname').value;
        var admintype = document.getElementById('edt_admintype').value;

        var s = {
            username:username,
            fullname:fullname,
            admintype:admintype
        };

        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function (){
            if(this.readyState==4 && this.status==200)
            {
                var output = this.responseText;
                console.log(output);
                if (output == 1) {
                    document.getElementById('er2').innerHTML = 'Data updated Successfully';
                    document.getElementById('er2').className = 'text-success';
                }
                else {
                    document.getElementById('er2').innerHTML = 'Something went wrong. Try again';
                    document.getElementById('er2').className = 'text-danger';
                }
                showAdmins();
            }
        };
        xmlhttp.open('GET','editadmin.php?q=' + JSON.stringify(s),true);
        xmlhttp.send();
    }
}