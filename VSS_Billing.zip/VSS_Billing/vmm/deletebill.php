<?php
include '../connection.php';
$orderid = $_REQUEST['orderid'];
$qr = "update ordertable_vmm set status='0' where id='$orderid'";
$res = mysqli_query($con,$qr);
if($res)
{
    header('Location:searchbyDate.php?upd=101');
}
else
{
    header('Location:searchbyDate.php?upd=102');
}