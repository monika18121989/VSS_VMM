<?php
include("../cart.php");
include("../connection.php");
@session_start();
if(!isset($_SESSION['ADMIN']))
{
    header("Location:../index.php");
}
if(isset($_SESSION['products'])) {
    unset($_SESSION['products']);
}

$invoiceno = "";

$qr = "select DISTINCT name from customertable_vmm order by name";
$res = mysqli_query($con,$qr);
$ar = [];
$num = 0;
while($row = mysqli_fetch_array($res))
{
    $ar[$num] = $row[0];
    $num++;
}


$qr1 = "select invoiceno from ordertable_vmm order by invoiceno desc";
$res1 = mysqli_query($con,$qr1);
if(mysqli_num_rows($res1))
{
    $row1 = mysqli_fetch_array($res1);
    $invoiceno = $row1['invoiceno'] + 1;
}
else
{
    $invoiceno = 1001;
}

//var_dump($ar);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>VMM - Bill</title>
    <?php include '../headerfiles.php'; ?>
    <script src="myjs/order_vmm.js"></script>
    <script>

        var SRNO = 1;
        var rowCount = 0;
        var a = ['','one ','two ','three ','four ', 'five ','six ','seven ','eight ','nine ','ten ','eleven ','twelve ','thirteen ','fourteen ','fifteen ','sixteen ','seventeen ','eighteen ','nineteen '];
        var b = ['', '', 'twenty','thirty','forty','fifty', 'sixty','seventy','eighty','ninety'];

        $( function() {
            $( "#dated" ).datepicker({ minDate: -10, maxDate: "+1M +10D", dateFormat: 'dd-mm-yy' });
        } );

        function addRow()
        {
            var tblRef = document.getElementById('tbl_Items').getElementsByTagName('tbody')[0];

            rowCount = tblRef.rows.length + 1;

            // Insert a row at the end of table
            var newRow = tblRef.insertRow();

            // Insert a cells in the row
            var cell1 = newRow.insertCell(0);
            var cell2 = newRow.insertCell(1);
            var cell3 = newRow.insertCell(2);
            var cell4 = newRow.insertCell(3);
            var cell5 = newRow.insertCell(4);
            // var cell6 = newRow.insertCell(5);
            // Insert a cells in the row

            // cell1.innerHTML =  '<label class=fw-bold name="lbl'+ rowCount +'" id="lbl'+ rowCount +'">'+ rowCount +'</label>';
            cell1.innerHTML = '<textarea name="descp'+rowCount+'" id="descp'+rowCount+'" class="form-control"></textarea>';
            cell2.innerHTML = '<input type="number" name="qty'+rowCount+'" id="qty'+rowCount+'" class="form-control">';
            cell3.innerHTML = '<input type="number" name="rate'+rowCount+'" id="rate'+rowCount+'" class="form-control">';
            cell4.innerHTML = '<input type="number" name="total'+rowCount+'" id="total'+rowCount+'" class="form-control">';
            cell5.innerHTML = '<a class="btn btn-sm btn-danger" onclick="deleteRow(this)">Delete</a>';

        }

        function deleteRow(r)
        {
            var i = r.parentNode.parentNode.rowIndex;
            document.getElementById("tbl_Items").deleteRow(i);
            rowCount = document.getElementById('tbl_Items').getElementsByTagName('tbody')[0].rows.length + 1;
        }

        function getBalance()
        {
            var grandtotal = parseInt(document.getElementById('gtotal').value);
            var advance = parseInt(document.getElementById('advance').value);
            var balance = grandtotal - advance;
            document.getElementById('balance').value = balance;
            var num = grandtotal;

            if ((num = num.toString()).length > 9) return 'overflow';
            n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
            if (!n) return; var str = '';
            str += (n[1] != 0) ? (a[Number(n[1])] || b[n[1][0]] + ' ' + a[n[1][1]]) + 'crore ' : '';
            str += (n[2] != 0) ? (a[Number(n[2])] || b[n[2][0]] + ' ' + a[n[2][1]]) + 'lakh ' : '';
            str += (n[3] != 0) ? (a[Number(n[3])] || b[n[3][0]] + ' ' + a[n[3][1]]) + 'thousand ' : '';
            str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'hundred ' : '';
            str += (n[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) : '';
            // alert(str);
            document.getElementById('amt_words1').innerHTML = str + " only";
        }

        $( function() {
            var availableTags = <?php echo json_encode($ar); ?>;
            console.log(availableTags);
            $( "#name1" ).autocomplete({
                source: availableTags
            });
        } );

    </script>
</head>
<body onload="showCartinTable([])">
<div class="container">
    <?php include '../adminheader.php'; ?>
    <div  id="printPage">
        <div class="row">
            <div class="col-12 col-sm-12">
                <h6 class="text-center text-decoration-underline">INVOICE</h6>
            </div>
<!--            <div class="col-4" style="font-size: 11px;">-->
<!--                <p class="m-0">3, Queens Road, Amritsar - 143001</p>-->
<!--                <p class="m-0">Ph-0183-2973735, Mb- 98554-47487</p>-->
<!--                <p class="m-0">E-mail : vssasr@gmail.com</p>-->
<!--            </div>-->
        </div>
<!--        <div class="row">-->
<!--            <div class="col-12">-->
<!---->
<!--            </div>-->
<!--        </div>-->
        <div class="row">
<!--            <div class="col-4 col-sm-4"></div>-->
            <div class="col-12 col-sm-12">
                <img src="vmmlogo.jpeg" width="100" height="80" style="position: absolute;margin-left: 85px;margin-top: 10px;">
                <h1 class="fw-bold text-center" style="color: #993367;">Veenus Mind Media</h1>
                <h5  class="text-center" style="color: #F76800;">Information Technology & Services</h5>
                <p class="m-0 text-center" style="font-size: 11px;">Near Hotel Veenus International, Queens's Road, Amritsar</p>
                <p class="m-0 text-center" style="font-size: 11px;">Ph: 0183-5006563 (M) 99144-87487</p>
                <p class="m-0 mb-3 text-center" style="font-size: 11px;">Email: office@vmmeducation.com</p>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-7 col-7">
                <div class="border border-dark p-2" style="border-radius:10px;">
                    <form id="frm_Customer">
                    <div class="row">
                        <div class="col-sm-2 col-2">
                            <label class="fw-bold mt-2">Name</label>
                        </div>
                        <div class="col-sm-10 col-10">
                            <input type="text" id="customerid" name="customerid" value="0" hidden>
                            <input type="text" class="form-control" name="name1" id="name1" onblur="getCustomerInfo()" data-rule-required="true" data-msg-required="*">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-2 col-2">
                            <label class="fw-bold mt-2">Address</label>
                        </div>
                        <div class="col-sm-10 col-10">
                            <textarea class="form-control" name="address" id="address" data-rule-required="true" data-msg-required="*"></textarea>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-4 col-4">
                            <label class="fw-bold">City</label>
                            <input type="text" name="city" id="city" class="form-control" data-rule-required="true" data-msg-required="*">
                        </div>
                        <div class="col-sm-4 col-4">
                            <label class="fw-bold">State</label>
                            <input type="text" name="state" id="state" class="form-control" data-rule-required="true" data-msg-required="*">
                        </div>
                        <div class="col-sm-4 col-4">
                            <label class="fw-bold">Country</label>
                            <input type="text" class="form-control" name="country" id="country" data-rule-required="true" data-msg-required="*">
                        </div>
                    </div>
<!--                    <div class="row">-->
<!--                        <div class="col-sm-3 col-3">-->
<!--                            <label class="fw-bold mt-2">Country</label>-->
<!--                        </div>-->
<!--                        <div class="col-sm-9 col-9">-->
<!--                            <input type="text" class="form-control" name="country" id="country">-->
<!--                        </div>-->
<!--                    </div>-->
                </form>
                </div>
            </div>
            <div class="col-sm-5 col-5 border border-dark" style="border-radius:10px;">
                <form id="frm_Invoice">
                <div class="row p-2">
                    <div class="col-sm-5 col-5">
                        <label class="fw-bold mt-2">Invoice No.</label>
                    </div>
                    <div class="col-sm-7 col-7">
                        <input type="text" class="form-control" value="<?php echo $invoiceno; ?>" readonly name="invoiceno" id="invoiceno" data-rule-required="true" data-msg-required="*">
                    </div>
                </div>
                <div class="row p-2">
                    <div class="col-sm-5 col-5">
                        <label class="fw-bold mt-2">Dated</label>
                    </div>
                    <div class="col-sm-7 col-7">
                        <input type="text" class="form-control" name="dated" id="dated" data-rule-required="true" data-msg-required="*">
                    </div>
                </div>
                <div class="row p-2">
                    <div class="col-sm-5 col-5">
                        <label class="fw-bold mt-2">Order No.</label>
                    </div>
                    <div class="col-sm-7 col-7">
                        <input type="text" class="form-control" name="orderno" id="orderno">
                    </div>
                </div>
                </form>
            </div>
        </div>
        <div class="row mt-2">
            <div class="col-sm-7 col-7">
                <div class="border border-dark" style="border-radius:10px;padding-bottom: 10px;">
                    <form id="frm_Terms">
                    <div class="row p-1">
                        <div class="col-sm-12 col-12">
                            <label class="fw-bold">Terms of Payments</label>
                        </div>
                        <div class="col-sm-12 col-12">
                            <input type="text" class="form-control" name="payment_terms" id="payment_terms" data-rule-required="true" data-msg-required="*">
                        </div>
                    </div>
                    </form>
                </div>
            </div>
            <div class="col-sm-5 col-5">
                <div class="border border-dark p-2" style="border-radius:10px;padding-right:10px;display:block;margin:0px -12px 0px -12px">
                    <div class="row">
                        <div class="col-sm-12 col-12 text-center p-1">
                            <label class="fw-bold">Intellectual Rights Transferred</label>
                        </div>
                        <div class="col-sm-2 col-2 offset-3 text-left p-1">
                            <input type="radio" checked name="transfer_rights" id="trans_rgt_Yes" value="Yes">&nbsp;Yes
                        </div>
                        <div class="col-sm-2 col-2  text-left p-1">
                            <input type="radio" name="transfer_rights" id="trans_rgt_No" value="No">&nbsp;No
                        </div>
                        <div class="col-sm-2 col-2 text-left p-1">
                            <input type="radio" name="transfer_rights" id="trans_rgt_NA" value="NA">&nbsp;NA
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-sm-12 col-12">
                <div id="div_Items" class="bg-light p-2 mb-3 PDF">
                    <form id="frm_Items">
                        <div class="row">
                        <div class="col-4 col-sm-4">
                            <label for="descp1" class="fw-bold">Description</label>
                            <textarea name="descp1" id="descp1" class="form-control"></textarea>
                        </div>
                        <div class="col-2 col-sm-2">
                            <label for="qty1" class="fw-bold">Qty/Man Hours</label>
                        <input type="number" name="qty1" id="qty1" class="form-control">
                        </div>
                            <div class="col-2 col-sm-2">
                                <label for='rate1' class="fw-bold">Rate</label>
                                <input type="number" name="rate1" id="rate1" class="form-control">

                            </div>
                            <div class="col-2 col-sm-2">
                                <label for="total1" class="fw-bold">Total</label>
                                <input type="number" name="total1" id="total1" class="form-control">
                            </div>
                            <div class="col-2 col-sm-2 text-end">
                                <button type="button" class="btn btn-outline-warning btn-sm mt-4" onclick="addToCart()">Add To Cart</button>
                            </div>
                        </div>
                    </form>
                </div>

                <div class="mt-2 mb-2 p-1" style="min-height: 100px;border:0px solid #868484;" id="div_CartItems"></div>
    <!--            <form id="frm_Items">-->
    <!--                <table class="table table-bordered" id="tbl_Items">-->
    <!--                <thead>-->
    <!--                    <th>Description</th>-->
    <!--                    <th width="15%">Qty/Man Hours</th>-->
    <!--                    <th width="15%">Rate</th>-->
    <!--                    <th width="15%">Total</th>-->
    <!--                    <th width="5%"></th>-->
    <!--                </thead>-->
    <!--                <tbody>-->
    <!--                <tr>-->
    <!--                    <td><textarea name="descp1" id="descp1" class="form-control"></textarea></td>-->
    <!--                    <td><input type="number" name="qty1" id="qty1" class="form-control"></td>-->
    <!--                    <td><input type="number" name="rate1" id="rate1" class="form-control"></td>-->
    <!--                    <td><input type="number" name="total1" id="total1" class="form-control"></td>-->
    <!--                    <td></td>-->
    <!--                </tr>-->
    <!--                </tbody>-->
    <!--                <thead>-->
    <!--                <th>-->
    <!--                    <button type="button" class="btn btn-outline-secondary btn-sm" onclick="addRow()">+</button>-->
    <!--                </th>-->
    <!--                <th colspan="4" class="text-end">-->
    <!---->
    <!--                </th>-->
    <!--                </thead>-->
    <!--            </table>-->
    <!--            </form>-->
            </div>
        </div>

        <div class="row mt-2">
            <div class="col-sm-6 col-6">
                <div class="border border-dark p-2" style="border-radius:10px;">
                    <label class="fw-bold">AMOUNT PAYABLE (in words):</label><br><br>
                    <label id="amt_words1">_______________________________________________________</label><br><br>
<!--                    <label id="amt_words2">_______________________________________________________</label>-->
                </div>
            </div>
            <div class="col-sm-6 col-6">
<!--                <div class="row">-->
<!--                    <div class="col-5 offset-3 text-end">-->
<!--                        <label class="fw-bold mt-2">Total</label>-->
<!--                    </div>-->
<!--                    <div class="col-4 col-sm-4">-->
<!--                        <input type="text" class="form-control" name="total" id="total" value="0">-->
<!--                    </div>-->
<!--                </div>-->

<!--                <table class="table table-bordered">-->
<!--                    <tr>-->
<!--                        <th>Grand Total</th>-->
<!--                        <td>-->
<!---->
<!--                        </td>-->
<!--                    </tr>-->
<!--                    <tr>-->
<!--                        <th>Advance</th>-->
<!--                        <td></td>-->
<!--                    </tr>-->
<!--                    <tr>-->
<!--                        <th>Balance</th>-->
<!--                        <td></td>-->
<!--                    </tr>-->
<!--                </table>-->

                <div class="row">
                    <div class="col-5 offset-3 text-end border border-1 border-dark">
                        <label class="fw-bold mt-2">Grand Total</label>
                    </div>
                    <div class="col-4 col-sm-4 border border-1 border-dark">
                        <div class="row">
                            <div class="col-2 col-sm-2 text-end mt-1">
                                <i class="fas fa-rupee-sign"></i>
                            </div>
                            <div class="col-9 col-sm-9" style="margin-left: -12px;">
                                <input type="text" class="form-control" style="padding-left:0px;padding-right:0px;" name="gtotal" id="gtotal" value="0" onkeyup="getBalance()">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-5 offset-3 text-end border border-1 border-dark">
                        <label class="fw-bold mt-2">Advance</label>
                    </div>
                    <div class="col-4 col-sm-4 border border-1 border-dark">
                        <div class="row">
                            <div class="col-2 col-sm-2 text-end mt-1">
                                <i class="fas fa-rupee-sign"></i>
                            </div>
                            <div class="col-9 col-sm-9" style="margin-left: -12px;">
                                <input type="text" class="form-control" style="padding-left: 0px;padding-right: 0px;" name="advance" id="advance" value="0" onkeyup="getBalance()">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-5 offset-3 text-end border border-1 border-dark">
                        <label class="fw-bold mt-2">Balance</label>
                    </div>
                    <div class="col-4 col-sm-4 border border-1 border-dark">
                        <div class="row">
                            <div class="col-2 col-sm-2 text-end mt-1">
                                <i class="fas fa-rupee-sign"></i>
                            </div>
                            <div class="col-9 col-sm-9" style="margin-left: -12px;">
                                <input type="text" class="form-control" style="padding-left: 0px;padding-right: 0px;" name="balance" id="balance" value="0" readonly>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row m-2">
        <div class="col-sm-3 offset-5">
            <button type="button" onclick="generateBill()" class="btn btn-lg" style="background-color: #F76800;color:#ffffff;" id="btn_bill">Generate Bill</button>
        </div>
    </div>
    <div class="row">
        <div class="col-7 col-sm-7">
            <p class="fw-lighter m-0" style="font-size: 11px;">* Interest will be charged @18% from the date of invoice.</p>
            <p class="fw-lighter m-0" style="padding-left: 12px;font-size: 11px;">if not paid within due date.</p>
            <h6 class="fw-lighter m-0" style="font-size: 11px;">* Subject to Amritsar(India) Jurisdiction only.</h6>
<!--            <h6 class="fw-lighter m-0" style="font-size: 11px;">* Taxable person paying tax in terms of notification No. 2/2019 Central Tax</h6>-->
<!--            <h6 class="fw-lighter m-0 mb-3" style="padding-left: 12px;font-size: 11px;">(Rate) dated 07.03.2019, not eligible to collect tax on supplies.</h6>-->
        </div>
        <div class="col-5 col-sm-5">
            <h6 class="text-end">For Veenus Mind Media</h6>
            <h6 class="text-end mt-5">Authorised Signatory</h6>
        </div>
    </div>
    <div class="row">
        <div class="col-12 col-sm-12 p-2 border border-1 border-dark">
            <h6><span class="text-decoration-underline">For Online Payment</span> :-</h6>
            <div class="row">
                <div class="col-sm-6 col-6">
                    <strong style="margin-left:20px;">Bank Name:- </strong><span>Punjab National Bank</span>
                </div>
                <div class="col-sm-6 col-6">
                    <strong>IFSC Code:- </strong><span>PUNB0013010</span>
                </div>
            </div>
            <div class="row">
            <div class="col-sm-6 col-6">
                <strong style="margin-left:20px;">Account No:- </strong><span>01301131000365</span>
            </div>
            <div class="col-sm-6 col-6">
                <strong>Account Name:- </strong><span>VMM Education</span>
            </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-12 col-12 text-center mt-3" style="font-size: 11px;">
            <p>
                Veenus Mind Media is Software Development arm of VMM Education
            </p>
        </div>
    </div>
    <div class="row">
        <div class="col-12 col-sm-12 text-center">
            <p class="m-0 mb-1" style="font-size: 11px;"><a href="http://vmmeducation.com/" target="_blank">visit us at:- www.veenusmindmedia.com</a></p>
        </div>
    </div>
</div>
</body>
</html>