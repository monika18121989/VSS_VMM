<?php
@session_start();
$val = "";
if(!isset($_SESSION['ADMIN']))
{
    header("Location:index.php");
}
if(isset($_REQUEST['q']))
{
    if($_REQUEST['q'] == 'byname')
    {
        $val = "byname";
    }
    if($_REQUEST['q'] == 'bydate')
    {
        $val = "bydate";
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>VSS - Homepage</title>
    <?php include 'headerfiles.php'; ?>

    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.css">
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.js"></script>

    <script>
        $( function() {
            // $( "#datefrom" ).datepicker({ dateFormat: 'dd-mm-yy' });
            // $( "#dateto" ).datepicker({ minDate: 0, maxDate: "+1M +10D", dateFormat: 'dd-mm-yy' });
            var from = $('#datefrom').datepicker({ dateFormat: 'dd-mm-yy' }).
            on('change', function() {
                var date = from.datepicker('getDate');
                var endDate = new Date(date);
                endDate.setDate(endDate.getDate() + 14);
                $('#dateto').datepicker('option', { minDate: date, maxDate: endDate });
            });
            var to = $('#dateto').datepicker({ dateFormat: 'dd-mm-yy' }).
            on('change', function() {
                from.datepicker('option', { maxDate: to.datepicker('getDate') });
            });
        } );

        // $(document).ready( function () {
        //     $('#table_id').DataTable();
        // } );
    </script>
</head>
<body>
<div class="container">
    <?php include 'adminheader.php'; ?>
    <div class="row p-2">
        <div class="col-sm-12 col-12">
            <h3 class="text-center">Search Bill</h3>
        </div>
    </div>
    <?php
    if($val=='byname')
    {
    ?>
        <div class="row p-2">
            <div class="col-6 col-sm-6 offset-3">
                <input type="text" placeholder="Type Customer Name" onkeyup="showBillbyName()" name="searchcname" id="searchcname" class="form-control">
            </div>
        </div>
    <?php
    }
    if($val=='bydate')
    {
    ?>
        <div class="row p-2">
            <div class="col-2 col-sm-2 offset-4">
                <input type="text" placeholder="Start Date" name="datefrom" id="datefrom" class="form-control">
            </div>
            <div class="col-2 col-sm-2">
                <input type="text" placeholder="End Date" name="dateto" id="dateto" class="form-control">
            </div>
            <div class="col-sm-1 col-1">
                <button type="button" class="btn btn-warning" onclick="showBillbyDate()">Search</button>
            </div>
        </div>
    <?php
    }
    ?>
    <div class="row p-4">
        <div class="col-sm-12 col-12">
            <div id="output">
                <table id="table_id">
                    <tr>
                        <th></th>
                    </tr>
                </table>

            </div>
        </div>
    </div>
</div>

<!-- The Modal (Order Detail)-->
<div class="modal fade" id="mdl_OrderDetail">
    <div class="modal-dialog">
        <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title">Order Detail (<span id="orderid"></span>)</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <!-- Modal body -->
            <div class="modal-body">
                    <div class="col-12 col-sm-12">
                        <div id="output_OrderDetail"></div>
                    </div>
            </div>

            <!-- Modal footer -->
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
            </div>

        </div>
    </div>
</div>
<!-- The Modal (Order Detail)-->

</body>
</html>