<?php
include 'connection.php';
$username = $_REQUEST['username'];
$qr = "update admintable set status='0' where username='$username'";
$res = mysqli_query($con,$qr);
if($res)
{
    header('Location:viewadmin.php?upd=101');
}
else
{
    header('Location:viewadmin.php?upd=102');
}